import pandas as pd

from mlxtend.frequent_patterns import apriori, association_rules

from pandas import get_dummies

from sklearn.preprocessing import OneHotEncoder

df = pd.read_csv("retail_dataset.csv")
print(df.head())
print("---------------------------------------------------------------------------A1")


items =df['0'].unique()
final_list =[]
for index, row in df.iterrows():
    labels = {}
    uncommons = list(set(items) - set(row))
    commons =  list(set(items).intersection(row))
    for uc in uncommons:
        labels[uc] = 0
        for com in commons:
            labels[com] = 1
            final_list.append(labels)
#             """encoded values are appended that is forming 317 dictionaries"""
            print(final_list)
            print("---------------------------------------------------------------------------A2")
            print(uncommons)
            print("---------------------------------------------------------------------------A3")
            print(commons)
            print("---------------------------------------------------------------------------A4")
            print(items)
            print("---------------------------------------------------------------------------A5")

final_data_frame = pd.DataFrame(final_list)
freq_items = apriori(final_data_frame, min_support=0.2, use_colnames=True, verbose=1)
print(freq_items.head())
print("---------------------------------------------------------------------------A6")

"""Sir in the below -- you asked us to try without .head """
final_data_frame = pd.DataFrame(final_list)
freq_items = apriori(final_data_frame, min_support=0.2, use_colnames=True, verbose=1)
print(freq_items)
print("---------------------------------------------------------------------------A6.1")
final_association = (freq_items.to_csv("final_2_output.csv"))
print(final_association)
print("---------------------------------------------------------------------------A6.2")

freq_items.head = freq_items.astype(bool)
print(freq_items.head)
print("---------------------------------------------------------------------------A7")

"""In the below we come to know-->If & Then-->that is cause and effect & certainty and dissimilarity
-- I think towards Association of Products"""
final_association = association_rules(freq_items,metric="confidence",min_threshold=0.6,num_itemsets=1)
print(final_association)
print("---------------------------------------------------------------------------A8")

final_association = (final_association.to_csv("final_2.0_output.csv"))
print(final_association)
print("---------------------------------------------------------------------------A8.1")




