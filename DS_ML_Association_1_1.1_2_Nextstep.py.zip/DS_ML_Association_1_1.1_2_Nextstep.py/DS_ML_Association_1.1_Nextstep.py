import pandas as pd


from mlxtend.frequent_patterns import apriori, association_rules
from mlxtend.preprocessing import TransactionEncoder
from numpy.f2py.crackfortran import commonpattern
from numpy.ma.extras import row_stack

from sklearn.preprocessing import OneHotEncoder


from toolz import itemfilter
from toolz.compatibility import iteritems



df = pd.read_csv("retail_dataset.csv")
print(df.head())
print("---------------------------------------------------------------------------A1")



items = (df['0'].unique())
print(items)
print("---------------------------------------------------------------------------A2")
encoded_vals = []
for index, row in df.iterrows():
    labels = {}
    uncommons = list(set(items) - set(row))
    commons = list(set(items).intersection(row))
    for uc in uncommons:
        labels[uc] = 0
    for com in commons:
        labels[com] = 1
    encoded_vals.append(labels)
    print(encoded_vals)
print("---------------------------------------------------------------------------A3")


"""In the below code - the 9 items in different rows are in columns - and the items are in alphabetical
 order - and in each rows the available items are denoted as True and non available as False """

encoded_df = pd.get_dummies(df.stack()).groupby(level=0).max()
print(encoded_df.head())
print("---------------------------------------------------------------------------A4")
ohe_df = pd.DataFrame(encoded_vals)
print(ohe_df)
print("---------------------------------------------------------------------------A5")

freq_items = apriori(ohe_df, min_support = 0.2, use_colnames = True, verbose = 1)
print(freq_items)
print("---------------------------------------------------------------------------A6")
print(freq_items.head())
print("---------------------------------------------------------------------------A7")



print(items)
print("---------------------------------------------------------------------------A8")
print(freq_items)
print("---------------------------------------------------------------------------A9")
final_association = (freq_items.to_csv("final_1.1_output.csv"))
print(final_association)
print("---------------------------------------------------------------------------A10")
