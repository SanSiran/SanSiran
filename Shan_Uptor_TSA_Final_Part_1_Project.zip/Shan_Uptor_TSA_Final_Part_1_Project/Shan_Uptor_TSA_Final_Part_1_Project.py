import pandas as pd

import numpy as np

print("############################### STEP--1 #######################################")
"""Real-world application of TSA """

"""To perform the time series analysis, we have to follow the following steps:

@ Collecting the data and cleaning it

@ Preparing Visualization with respect to time vs key feature

@ Observing the stationarity of the series

@ Developing charts to understand its nature.

@ Model building

@ Extracting insights from prediction"""

df = pd.read_csv("Manuf_Sample.csv")
print(df)
print("---------------------------------------------------------------------A1")

# Pre-processing

shape = df.shape
print(shape)
print("---------------------------------------------------------------------A2")

col_names = df.columns
print(col_names)

print("---------------------------------------------------------------------A3")

pd.set_option("display.max_columns", None)
pd.set_option("display.max_rows", None)

print(df)
print("---------------------------------------------------------------------A4")

# view summary of dataset
df.info()
print("---------------------------------------------------------------------A5")

print(df.describe())

"""In the above code output we observe---> Descriptive Statistics for Numerical Columns generated 

count: Total number of non-null values in the column.
mean: Average value of the column.
std: Standard deviation, showing how spread out the values are.
min: Minimum value in the column.
25%: 25th percentile (Q1).
50%: Median value (50th percentile).
75%: 75th percentile (Q3).
max: Maximum value in the column."""

print("---------------------------------------------------------------------A6")

percentiles = [.20, .40, .60, .80]
include = ['object', 'float', 'int']

desc = df.describe(percentiles=percentiles, include=include)

print(desc)

print("---------------------------------------------------------------------A7")
"""From the below codes output -- to have an overview of a DataFrame’s numeric and object columns."""

"""For string data,

count: Total number of non-null values.
unique: The number of unique values.
top: The most frequent value.
freq: The frequency of the most common value."""

desc = df["Operation_Mode"].describe()
print(desc)
print("---------------------------------------------------------------------A8")

desc = df["Efficiency_Status"].describe()
print(desc)
print("---------------------------------------------------------------------A9")

"""In the below code -- we reorder rows by column --to rearrange rows by the DataFrame’s index. 
Combine both methods to explore our dataset from different angles."""

# making data frame from csv file
df = pd.read_csv("Manuf_Sample.csv")

# sorting by first name
df.sort_values(["Machine_ID"], inplace=True)

# making a bool series
bool_series = (["Timestamp", "Machine_ID", "Operation_Mode", "Efficiency_Status"])

# display data
print(df[bool_series])
"""In the above code output -- we have Extracted few insights from our perspective prediction"""
"""In a manufacturing plant, a machine categorized as Idle is available but not actively producing, 
Active means it's engaged in production, and Maintenance signifies it's undergoing planned or 
unplanned work to ensure functionality. 

Here's a more detailed explanation:

Idle:
A machine is considered idle when it's ready and capable of running but is not actively engaged in 
production due to factors like waiting for materials, workflow delays, or scheduled downtime for 
setup or changeover. 

Active:
An active machine is one that is currently engaged in the production process, performing its intended
tasks and contributing to output.

Maintenance:
A machine is in maintenance when it's temporarily out of service for planned or unplanned 
activities aimed at ensuring its continued functionality and reliability. This can include 
routine checks, repairs, or replacements of parts. """

"""Note---In our Use case --Objective is "Predictive_Maintenance" -- but if our Objective is 
"Preventive Maintenance" --> Machine ID which are categorised as Idle & Maintenance will not be
engaged into production __ we need to know the basic understanding between "Preventive Maintenance"
and enhancing towards the next stage of "Predictive_Maintenance" --> Kindly find the details 
in attachment (Inference) """

print("---------------------------------------------------------------------A10")

print(df.dtypes)
# In the above by default our model reads the timestamp as object - so our model need to read it as
# Time series in this use case

print("---------------------------------------------------------------------A11")

# Check for missing values
print(df.isnull().sum())
# If no missing values are found, we can move forward with further analysis.
print("---------------------------------------------------------------------A12")

"""In the below code our model reads the data set as per Time series"""
df = pd.read_csv("Manuf_Sample.csv", date_parser=["Timestamp"])
print(df)

print("---------------------------------------------------------------------A13")

print(df.dtypes)
# In the output - model reads as object by default - but by using  the key word date_parser we can
# manipulate Date & Time series ( that is changed into Date & Time )

print("---------------------------------------------------------------------A14")

df.set_index("Timestamp", inplace=True)
print(df)
# In the above code output __Timestamp is changed into row index and rest all others into columns
print("---------------------------------------------------------------------A15")

import matplotlib.pyplot as plt

import seaborn as sns

"""The below plots output(histograms of the variables) depicts & indicates(signal processing and 
control systems_as per our Dataset Features)_zigzag wave form --> indicates_a function that 
increases linearly with time and then jumps back to zero at the end of each period-->"period" or 
"time interval" refers to a specific duration or interval of time, measured in units like seconds, 
minutes, hours, days, weeks, months, or years, and used to quantify the passage of time or the 
duration of events--In our use case as per the dataset features -- the plot output 
depicts --> seconds, minutes, hours__ & __ indicates towards the observation -->that our time-series 
data has a Stationary Characteristics."""

df = pd.read_csv("Manuf_Sample.csv")

# plot histograms of the variables
series = df.loc[:"value"].values
df.plot(figsize=(14, 10), legend='Machine_ID', title='VARIABLE__DISTRIBUTION')
plt.xlabel("x ('Row_Index')")
plt.ylabel("y ('Distribution_of_Values')")
plt.show()
print("---------------------------------------------------------------------A16")

# plot histograms of the variables

df = pd.read_csv("Manuf_Sample.csv", header=0, index_col=0)
df.plot(figsize=(14, 10), title='VARIABLE__DISTRIBUTION')
plt.ylabel("y ('Distribution_of_Values')")
plt.show()

"""NOTE : From the above plots we observe that --> stationary time series are not dependent on time."""

# Plot histograms for numerical columns
numerical_cols = ['Machine_ID', 'Temperature_C', 'Vibration_Hz', 'Power_Consumption_kW',
                  'Production_Speed_units_per_hr', 'Predictive_Maintenance_Score',
                  'Network_Latency_ms', 'Packet_Loss_%', 'Quality_Control_Defect_Rate_%',
                  'Error_Rate_%']

df[numerical_cols].hist(bins=20, figsize=(16, 32))
plt.show()

print("############################### STEP--2 #######################################")

"""NOTE : In the below codes _ we forward further towards better understanding __whether our dataset 
features are associated or not ?--> towards the statement as follows -->("Time series are stationary 
if they do not have trend or seasonal effects--stationary time series are not dependent on time")"""

"""Time series decomposition is important -- better understanding and analyzing time series data"""
"""visually inspect -- the time series data """
"""To uncover seasonality, we typically employ seasonal decomposition"""
"""visualize and analyze it, revealing the repetitive patterns that influence the data."""

"""Seasonality adds an exciting dimension to time series data. It refers to regular, repeating 
patterns that occur at fixed intervals. Think of the seasonal fluctuations in sales during holiday 
seasons or temperature variations throughout the year. Recognizing seasonality is essential for 
understanding the cyclic behavior of your data and can greatly enhance forecasting accuracy.

In our Use case -- fluctuations in Power_Consumption, Temperature, Vibration, Power consumption & 
Production_Speed_units_per_hr during 24 hours through out the day & other factors-Tea & Lunch Break 
(including food habits) which influence physically & mentally --> reflected in the work force production & 
Preventive and predictive management in a manufacturing plant.

NOTE -- >Power_Consumption,Temperature, Vibration & Motor engine oil (Manually sample oil are 
taken and checked in regular interval of time (months) - details not provided in our dataset) are 
the four important factors which influence the Predictive_Maintenance.

@ Compatibility --- Motor Engine oil ---> Temperature ---> Vibration --> Power_Consumption --->
towards--> Predictive_Maintenance"""

"""Note --->

"VIBRATION ANALYSIS" (Industrial maintenance scenario)___it is impossible to totally 
eliminate vibrations from engines, it is important to understand the sources(In a manufacturing 
plant, machine vibrations often stem from imbalance, misalignment, wear and tear, looseness, and 
resonance of components( bearings, shafts, gears, belts and other elements that make up mechanical 
systems.)) of vibration production and control them to acceptable levels. Kindly find the details 
in attachment (Inference)"""

""" "OIL ANALYSIS" (Industrial maintenance scenario)-- an early warning system -- routine inspection-->
3 Months or Less, Every 6 months, Annually  (Note - Apart from Oil analysis all others which 
fall under preventive maintenance -- Forwarding towards the next stage of Predictive maintenance 
dataset (use case scenario dataset- what we explore in our current project) --  Moreover the Motor 
Engine oil usage and its applications differ across Geo_Climate_Manufacturing plants location.

In detail __Tropical countries, generally located near the equator, experience warm temperatures 
year-round, while cold weather countries, typically in higher latitudes, have colder temperatures, 
especially during winter."""

""" "ELECTRICAL ANALYSIS" (Industrial maintenance scenario): Abnormalities in the electrical 
currents flowing through machinery pose serious safety risks."""

"""NOTE -->"VIBRATION ANALYSIS","OIL ANALYSIS","ELECTRICAL ANALYSIS"-->Under Preventive Maintenance """
"""As per our Objective _ our dataset comes under -- "PREDICTIVE MAINTENANCE"""

"""In the below -- we are decomposing the column in a data set (that is splitting) """
"""for seasonal decompose - statsmodels library need to be installed"""
"""pip install statsmodels"""

from statsmodels.tsa.seasonal import seasonal_decompose

# period=24 means Assuming hourly data
# Additive Decomposition: The time series is expressed as the sum of its components = Trend +
# Seasonal + Residual
# In our use case "Additive Decomposition" -- is suitable when the magnitude(scalar quantity)
# of seasonality doesn't vary with the magnitude of the time series.

result = seasonal_decompose(df['Temperature_C'], model='additive', period=24)
result.plot()
plt.show()
print("---------------------------------------------------------------------A17")

result = seasonal_decompose(df['Vibration_Hz'], model='additive', period=24)
result.plot()
plt.show()
print("---------------------------------------------------------------------A18")

result = seasonal_decompose(df['Production_Speed_units_per_hr'], model='additive', period=24)
result.plot()
plt.show()
print("---------------------------------------------------------------------A19")

result = seasonal_decompose(df['Power_Consumption_kW'], model='additive', period=24)
result.plot()
plt.show()
print("---------------------------------------------------------------------A20")

result = seasonal_decompose(df['Predictive_Maintenance_Score'], model='additive', period=24)
result.plot()
plt.show()
print("---------------------------------------------------------------------A21")

"""As per the above Plot -- we come to a conclusion that - Timeseries is combination of Trend, 
Seasonality and Residual error or random noise."""

"""Time series decomposition helps us break down a time series dataset into three main 
components:
@ Trend: The trend component represents the long-term movement in the data, representing the 
underlying pattern.
@ Seasonality: The seasonality component represents the repeating, short-term fluctuations caused 
by factors like seasons or cycles.
@ Residual (Noise): The residual component represents random variability that remains after removing 
the trend and seasonality. That is --> The residual component represents the random fluctuations or 
noise in the data that cannot be explained by the trend or seasonality. It is obtained by subtracting 
the trend and seasonality components from the original time series. 

By separating these components, we can gain insights into the behavior of the data and make better 
forecasts."""

print("############################### STEP--3 #######################################")

"""NOTE : In the below codes _ we forward further towards better understanding __whether our dataset 
features are associated or not ?--> towards the statement as follows -->("Time series are stationary 
when the --->Summary statistics calculated on the time series are consistent over time, like the mean 
or the variance of the observations.--stationary time series are not dependent on time")"""

"""The Augmented Dickey-Fuller (ADF) test is a statistical test used in time series analysis to 
determine if a time series is stationary or not, meaning if its statistical properties (like 
mean, variance, and auto correlation) are constant over time. It tests for the presence of a 
"unit root," which indicates non-stationarity."""

"""Hypotheses:
Null Hypothesis: The time series has a unit root (it's non-stationary). 
Alternative Hypothesis: The time series is stationary (or trend-stationary) does not have a unit root.

How it works:
The ADF test uses a regression model to test the null hypothesis. It examines the relationship 
between the current value of the time series and its lagged values.

The relationship between a current value and its past values (lagged values) is measured using 
auto correlation, which assesses the degree of similarity between a time series and its lagged 
versions. 

Here's a more detailed explanation:

Auto correlation: This statistical concept measures the correlation between a time series 
and its own lagged values. 

Lag: The lag refers to the time difference or number of periods between two observations in a 
time series. For example, a lag of 1 means comparing the current value with the previous value, 
a lag of 2 means comparing the current value with the value two periods prior, and so on.  
"""

from statsmodels.tsa.stattools import adfuller

# ADF Test
result = adfuller(df['Temperature_C'], autolag='AIC')
print(f'ADF Statistic: {result[0]}')
print(f'n_lags: {result[1]}')
print(f'p-value: {result[1]}')
for key, value in result[4].items():
    print('Critical Values:')
    print(f'   {key}, {value}')

adf_test = adfuller(df['Temperature_C'])
print("ADF Statistic:'Temperature_C'", adf_test[0])
print("p-value:", adf_test[1])

"""The p-value is obtained is lesser than significance level of 0.05 and the ADF statistic is 
lower than any of the critical values. Clearly, there is reason to reject the null hypothesis. 
So, the time series is in fact stationary."""

print("---------------------------------------------------------------------A22")

# ADF Test
result = adfuller(df['Vibration_Hz'], autolag='AIC')
print(f'ADF Statistic: {result[0]}')
print(f'n_lags: {result[1]}')
print(f'p-value: {result[1]}')
for key, value in result[4].items():
    print('Critical Values:')
    print(f'   {key}, {value}')

adf_test = adfuller(df['Vibration_Hz'])
print("ADF Statistic:'Vibration_Hz'", adf_test[0])
print("p-value:", adf_test[1])

"""The p-value is obtained is greater than significance level of 0.05 and the ADF statistic is 
lower than any of the critical values. Clearly, there is reason to reject the null hypothesis. 
So, the time series is in fact stationary."""

"""Note -->When the test statistic is lower than the critical value shown, you reject the null 
hypothesis and infer that the time series is stationary."""
print("---------------------------------------------------------------------A23")

# ADF Test
result = adfuller(df['Production_Speed_units_per_hr'], autolag='AIC')
print(f'ADF Statistic: {result[0]}')
print(f'n_lags: {result[1]}')
print(f'p-value: {result[1]}')
for key, value in result[4].items():
    print('Critical Values:')
    print(f'   {key}, {value}')

adf_test = adfuller(df['Production_Speed_units_per_hr'])
print("ADF Statistic:'Production_Speed_units_per_hr'", adf_test[0])
print("p-value:", adf_test[1])

"""The p-value is obtained is greater than significance level of 0.05 and the ADF statistic is 
lower than any of the critical values. Clearly, there is reason to reject the null hypothesis. 
So, the time series is in fact stationary."""

"""Note -->When the test statistic is lower than the critical value shown, you reject the null 
hypothesis and infer that the time series is stationary."""

print("---------------------------------------------------------------------A24")

# ADF Test
result = adfuller(df['Power_Consumption_kW'], autolag='AIC')
print(f'ADF Statistic: {result[0]}')
print(f'n_lags: {result[1]}')
print(f'p-value: {result[1]}')
for key, value in result[4].items():
    print('Critical Values:')
    print(f'   {key}, {value}')

adf_test = adfuller(df['Power_Consumption_kW'])
print("ADF Statistic:'Power_Consumption_kW'", adf_test[0])
print("p-value:", adf_test[1])

"""The p-value is obtained is greater than significance level of 0.05 and the ADF statistic is 
lower than any of the critical values. Clearly, there is reason to reject the null hypothesis. 
So, the time series is in fact stationary."""

"""Note -->When the test statistic is lower than the critical value shown, you reject the null 
hypothesis and infer that the time series is stationary."""

print("---------------------------------------------------------------------A25")

# ADF Test
result = adfuller(df['Predictive_Maintenance_Score'], autolag='AIC')
print(f'ADF Statistic: {result[0]}')
print(f'n_lags: {result[1]}')
print(f'p-value: {result[1]}')
for key, value in result[4].items():
    print('Critical Values:')
    print(f'   {key}, {value}')

adf_test = adfuller(df['Predictive_Maintenance_Score'])
print("ADF Statistic:'Predictive_Maintenance_Score'", adf_test[0])
print("p-value:", adf_test[1])

"""The p-value is obtained is greater than significance level of 0.05 and the ADF statistic is 
lower than any of the critical values. Clearly, there is reason to reject the null hypothesis. 
So, the time series is in fact stationary."""

"""Note -->When the test statistic is lower than the critical value shown, you reject the null 
hypothesis and infer that the time series is stationary."""
print("---------------------------------------------------------------------A26")

"""The above results depicts --> we can observe and conclude that our time-series data has 
a "Stationary characteristics"."""



