import pandas as pd

from mlxtend.frequent_patterns import apriori, association_rules

from pandas import get_dummies

from sklearn.preprocessing import OneHotEncoder

df = pd.read_csv("retail_dataset.csv")
print(df.head())
print("---------------------------------------------------------------------------A1")


items =df['0'].unique()
final_list =[]
for index, row in df.iterrows():
    labels = {}
    uncommons = list(set(items) - set(row))
    commons =  list(set(items).intersection(row))
    for uc in uncommons:
        labels[uc] = 0
        for com in commons:
            labels[com] = 1
            final_list.append(labels)
#             """encoded values are appended that is forming 317 dictionaries"""
            print(final_list)
            print("---------------------------------------------------------------------------A2")
            print(uncommons)
            print("---------------------------------------------------------------------------A3")
            print(commons)
            print("---------------------------------------------------------------------------A4")
            print(items)
            print("---------------------------------------------------------------------------A5")

final_data_frame = pd.DataFrame(final_list)
freq_items = apriori(final_data_frame, min_support=0.2, use_colnames=True, verbose=1)
print(freq_items.head())
print("---------------------------------------------------------------------------A6")

"""Sir in the below -- you asked us to try without .head """
final_data_frame = pd.DataFrame(final_list)
freq_items = apriori(final_data_frame, min_support=0.2, use_colnames=True, verbose=1)
print(freq_items)
print("---------------------------------------------------------------------------A6.1")
final_association = (freq_items.to_csv("final_2_output.csv"))
print(final_association)
print("---------------------------------------------------------------------------A6.2")

freq_items.head = freq_items.astype(bool)
print(freq_items.head)
print("---------------------------------------------------------------------------A7")

"""In the below we come to know-->If & Then-->that is cause and effect & certainty and dissimilarity
-- I think towards Association of Products"""
final_association = association_rules(freq_items,metric="confidence",min_threshold=0.6,num_itemsets=1)
print(final_association)
print("---------------------------------------------------------------------------A8")

final_association = (final_association.to_csv("final_2.0_output.csv"))
print(final_association)
print("---------------------------------------------------------------------------A8.1")

"""Note - technically by code - we need to group it and do association of the items """

"""What is the difference between confidence and support?
Support is a measure of the number of times an item set appears in a dataset. Confidence is a 
measure of the likelihood that an itemset will appear if another itemset appears. Support is 
calculated by dividing the number of transactions containing an item set by the total 
number of transactions"""

"""What is antecedent and consequent in association rule?
An association rule has two parts: an antecedent (if) and a consequent (then). An antecedent 
is an item found within the data. A consequent is an item found in combination with the antecedent."""

"""What are the three main types of antecedents?
Antecedents come in three different forms: events, objects, and people."""

"""Why are antecedents important?
Why are antecedents important? To understand and modify behavior, it's important to analyze the 
antecedents and consequences. When we understand the antecedents of a behavior we have information 
on the circumstances in which the behavior was reinforced and was punished 
(Miltenberger, 2004).9 Jan 2013"""

"""What is the support of a rule?
The support is simply the number of transactions that include all items in the antecedent and 
consequent parts of the rule. (The support is sometimes expressed as a percentage of the total 
number of r"""

"""What is frequent item set with example?
Frequent patterns are patterns ( for example, Itemsets, or substructures) that comes frequently 
in a data set. For example, a set of items, such as bread and butter, appear frequently together 
in a transaction data set which is a frequent itemset.29 Oct 2020"""

"""What is support and confidence in Apriori?
Apriori algorithm uses the following metrics to find such relationships: Support - Proportional 
frequency of an item in the database. Support(A) = Frequency(A) / # Total records. Confidence - how 
confident we are of an event, given another event. 
Confidence(A→B) = Probability(A & B) / Support(A)11 May 2022"""

"""Kulczynski. It can be viewed as an average of two confidence measures. That is, it is the average 
of two conditional probabilities: the probability of itemset B given itemset A, and the probability 
of itemset A given itemset B. Finally, given two itemsets, A and B, the cosine measure of A and B 
is defined as."""

"""The Kulczynski index is considered a dissimilarity measure rather than a similarity measure, 
meaning it indicates how different two sets of data are from each other, with a higher value 
signifying greater dissimilarity; it is commonly used in fields like ecology to compare species 
presence-absence data between different communities. 

Key points about Kulczynski:
Focus on rare species:
Unlike some other similarity measures, Kulczynski gives more weight to the presence of rare species, 
making it particularly useful when analyzing data where species occurrences are uneven.

Calculation:
The formula for Kulczynski involves calculating the proportion of shared species between two communities, 
giving a value between 0 (identical communities) and 1 (completely different communities). """

"""What is similarity or dissimilarity?
In Data science, the similarity measure is a way of measuring how data samples are related or closed 
to each other. On the other hand, the dissimilarity measure is to tell how much the data objects are 
distinct.




