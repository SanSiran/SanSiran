import pandas as pd


from mlxtend.frequent_patterns import apriori, association_rules

from numpy.f2py.crackfortran import commonpattern

from numpy.ma.extras import row_stack


from sklearn.preprocessing import OneHotEncoder


from toolz import itemfilter

from toolz.compatibility import iteritems

"""Objective - to find how often connection between products and their association - that is  frequently a item set 
occurs in a transaction"""

df = pd.read_csv("retail_dataset.csv")
print(df.head())
print("---------------------------------------------------------------------------A1")


"""The below -- To ensure the variables in the column are on the line -we do  with 0's and 1's -- To 
train the model to execute with the problem statement towards better understanding"""

items =df['0'].unique()
encoded_vals =[]
for index, row in df.iterrows():
    labels = {}
    uncommons = list(set(items) - set(row))
    commons =  list(set(items).intersection(row))
    for uc in uncommons:
        labels[uc] = 0
        for com in commons:
            labels[com] = 1
            encoded_vals.append(labels)
            
            """In the above -- encoded values are appended that is forming 317 dictionaries"""
            """Sir you asked us to -- Try the below code - to have a different idea"""
            
            print(encoded_vals)
            print("---------------------------------------------------------------------------A2")
            print(uncommons)
            print("---------------------------------------------------------------------------A3")
            print(commons)
            print("---------------------------------------------------------------------------A4")
            print(items)
            print("---------------------------------------------------------------------------A5")



"""In the below code - the 9 items in different rows are in columns - and the 9 items are in alphabetical
 order - and in each rows the available items are denoted as True and non available as False """

encoded_df = pd.get_dummies(df.stack()).groupby(level=0).max()
print(encoded_df.head())
print("---------------------------------------------------------------------------A6")
"""Sir you asked us to -- Try the below code - to have a different idea"""
print(df.stack())
print("---------------------------------------------------------------------------A7")
print((df.stack()).groupby)
print("---------------------------------------------------------------------------A8")
print((df.stack()).groupby(level=0).max())
print("---------------------------------------------------------------------------A9")
print(encoded_df)
print("---------------------------------------------------------------------------A10")


final_association = (encoded_df.to_csv("final_1_output.csv"))
print(final_association)
print("---------------------------------------------------------------------------A11")

# Find Frequent items using apriori algorithm

frequent_itemsets = apriori(encoded_df, min_support=0.2, use_colnames=True)
frequent_itemsets['length'] = frequent_itemsets['itemsets'].apply(lambda x: len(x))
print(frequent_itemsets)
print("---------------------------------------------------------------------------A12")

final_association_X = (frequent_itemsets.to_csv("final_1.0_output.csv"))
print(final_association_X)
print("---------------------------------------------------------------------------A13")

"""Conclusion -- Market Based Analysis is one of the key techniques used
by large relations to show associations between items.It allows retailers to identify relationships between 
the items that people buy together frequently. Given a set of transactions, we can find rules that 
will predict the occurrence of an item based on the occurrences of other items in the transaction."""
"""Product augmentation ---> is must in the above context"""
"""Note -- Augmented product is different"""

"""Student (Shan) observation -- Learned, Step-by-Step ---> Data understanding & To do and Not to do 
in Preprocessing steps towards valuable insight ( moreover i think the retail_dataset.csv is not a 
real time dataset -- i think the data set is created for learning purpose)"""

"""Sir, Iam Feeling great about your teaching attitude --  thank you for the opportunity"""



